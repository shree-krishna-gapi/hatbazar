import 'package:flutter/material.dart';
import 'package:flutterbuyandsell/config/ps_config.dart';
import 'package:flutterbuyandsell/config/ps_colors.dart';
import 'package:flutterbuyandsell/utils/utils.dart';
class AgriculturalVideo extends StatefulWidget {
  @override
  _AgriculturalVideoState createState() => _AgriculturalVideoState();
}

class _AgriculturalVideoState extends State<AgriculturalVideo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Text('dsfsdf'),
    );
  }
}



